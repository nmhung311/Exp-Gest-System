export { default } from "../app/components/SectionHeader"
